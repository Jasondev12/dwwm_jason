=== Plugin Name ===

Tiled Gallery Carousel Without JetPack

Contributors:raja3c, themepacific

Tags: Tiled gallery, carousel, gallery carousel, jetpack, Lightbox, Jetpack Lite

Requires at least: 3.4.1

Tested up to: 4.9.4

Stable tag: 2.9

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html



Tiled Gallery Carousel allows you to display image galleries in mosaic styles without Jetpack. 



== Description ==



There is no doubt that JetPack packed with tons of features. However, many users don't want all that monstrous codes in their blog for one or two modules. Also, You should connect your blog to wordpress.com to get the JetPack features.



I really like that Tiled Gallery with Full Screen carousel module in JetPack and don't want other modules. That's why I've made the this Tiled Gallery Carousel Without JetPack Plugin from JetPack.



Tiled Gallery with carousel will completely transform your galleries to new look and your users will love this. Tiled Gallery allows you to display image galleries in following styles, a rectangular mosaic, a square mosaic, and a circular grid. 





Demo Tiled Gallery :  [Demo link](http://demo.themepacific.com/plugin-tiled-gallery-carousel/2013/10/13/tiled-gallery-carousel-without-jetpack-wordpress-plugin/ "Demo Link")



 

If you like this plugin then follow ThemePacific on [Twitter](http://twitter.com/themepacific "Twitter"), [Facebook](http://facebook.com/themepacific "Facebook"), and [Google+](https://plus.google.com/u/0/111626044701452949912 "Google+")

 





== Installation ==



Download the Plugin here. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.



Tiled Gallery and Carousel: Go to TP Tiled Gallery > settings . There you will find more options.

 





== Frequently Asked Questions ==



**About Update?**



This plugin will be updated whenever JetPack releases new version.





== Upgrade Notice ==



= 2.9 =

Compatible with latest version of the WordPress 



== Changelog ==



= 2.9 =

* PHP 7 compatability issue fixed.
* json issue fixed
* New Settings Page added with more options




= 2.2 =

* Compatible with latest version of the WordPress. Will Be Actively Maintained



= 2.1 = 

* version not updated



= 2.0 = 

* Tested upto 4.0



= 1.9 = 

* Fatal error: Class 'Jetpack_Options' not found Fixed

* image_resize depreciated fixed



= 1.3 =

* Tested upto 3.9

= 0.1 =

*Initial Release
